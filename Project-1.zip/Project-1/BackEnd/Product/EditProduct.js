module.exports = CreateProduct =async(req,res)=>{
    const product = require('./Product')
    const mainProd = req.body.Name;
    const desc = req.body.Desc;
    const link = req.body.Link;
    const cat = req.body.Catagory;
   
    product.findOneAndUpdate({_id:req.params.id},{Catagory: cat, Link: link, Desc: desc})
    
   .then((prod) => {
    if(prod===null || prod==='')
    {
        res.status(202).json({
            success:"false",
       })
    }
    else{
        res.status(404).json({
            success:"true",
            prod
        })
    }
})
}