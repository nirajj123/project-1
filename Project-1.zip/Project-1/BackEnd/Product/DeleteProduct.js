module.exports = DeleteProduct =async(req,res)=>{
    const product = require('./Product')
    const mainId = req.params.id;
    product.findOneAndDelete({_id: mainId})
   .then((prod) => {
    if(prod)
    {
        res.status(202).json({
            success:"true",
       })
    }
    else{

        res.status(404).json({
        success:"false",
        prod
    })
    }
})
}