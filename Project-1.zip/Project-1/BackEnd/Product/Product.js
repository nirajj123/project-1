const mongoose = require('../MongoConnect');
const UserSchema=mongoose.Schema({
    Name:String,
    Catagory:String,
    Link: String,
    Desc: String,     
    // Token: String,
})
module.exports=mongoose.model('Product',UserSchema);