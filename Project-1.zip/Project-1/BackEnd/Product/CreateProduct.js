module.exports = CreateProduct =async(req,res)=>{
    const product = require('./Product')
    const name = req.body.Name;
    const catagory = req.body.Name;
    
    product.findOne({Name: name,Catagory: catagory})
    
   .then((prod) => {
    if(prod===null || prod==='')
    {
        const prod=product.create(req.body)
        res.status(202).json({
            success:"true",
       })
    }
    else{
        res.status(404).json({
            success:"false",
            prod
        })
    }
})
}