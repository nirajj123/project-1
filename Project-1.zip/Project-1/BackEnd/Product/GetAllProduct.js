module.exports = GertAllProduct =async(req,res)=>{
    const product = require('./Product')
    product.find()
    
   .then((prod) => {
    if(prod===null || prod==='')
    {
        res.status(202).json({
            success:"false",
       })
    }
    else{
        res.status(404).json({
            success:"true",
            prod
        })
    }
})
}