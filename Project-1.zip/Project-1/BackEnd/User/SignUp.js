module.exports = SignUp = async(req,res) =>{
const User = require('./User')
if(req.body.First_name || req.body.Last_name || req.body.Email || req.body.Password){
    const GetUser = User.findOne({Email: req.body.Email})
    .then(val=>{
        if(val==null || val==''){
            const user = req.body;
            const mainUser = User.create(user)
            .then(Acc => {
                res.status(202).json({
                    success : true,
                    Acc
                })
            })
        }
        else{
            res.status(404).json({
                success: false,
                Err: 'already user signUp'
            })
        }
    })
}
else{
    res.status(404).json({
        success : false,
    })
}
}