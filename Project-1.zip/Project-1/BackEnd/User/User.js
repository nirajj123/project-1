const mongoose = require('../MongoConnect');
const UserSchema=mongoose.Schema({
    First_name:String,
    Last_name:String,
    Email:String,
    Password:String,     
    // Token: String,
})
module.exports=mongoose.model('User',UserSchema);