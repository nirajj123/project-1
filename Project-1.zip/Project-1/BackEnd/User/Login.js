module.exports = Login = async(req,res) =>{
    const User = require('./User')
    if( req.body.Email || req.body.Password){
        const GetUser = User.findOne({Email: req.body.Email,Password: req.body.Password})
        .then(val=>{
            if(val==null || val==''){
                     res.status(202).json({
                        success : false,
                      
                })
            }
            else{
                res.status(404).json({
                    success: true,
                    val
                })
            }
        })
    }
    else{
        res.status(404).json({
            success : false,
        })
    }
    }