const express = require('express');
const router = express();
const Login = require('./User/Login');
const GetAllProduct = require('./Product/GetAllProduct')
const GetAllProductByCatagory = require('./Product/GetProductByCatagory');
const SignUp = require('./User/SignUp');

router.route('/Login').get(Login)
router.route('/SignUp').post(SignUp)
router.route('/Product/All').get(GetAllProduct)
router.route('/Category/Read').get(GetAllProductByCatagory)
module.exports = router;