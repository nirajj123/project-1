module.exports = MiddleWare =(req,res,next)=>{
    console.log('hello this is a middleware')
    next();
}