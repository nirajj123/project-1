module.exports = SignIn = (req,res) => {
  const sercretKey = process.env.Access_Token;
  const jwt = require('jsonwebtoken')
  const Admin = jwt.verify(req.body.Token,sercretKey);
  res.send(Admin);
}