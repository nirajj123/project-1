const mongoose = require('../MongoConnect');
const UserSchema=mongoose.Schema({
    Email:String,
    Password:String,     
    Token: String,
})
module.exports=mongoose.model('admins',UserSchema);