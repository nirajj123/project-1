module.exports=LoginAdmin=async(req,res)=>{
const admin = require('./Admin');
const jwt = require('jsonwebtoken')
const adminSchema = {
  Email: 'admin@gmail.com',
  Password: '123456'
}
admin.find().then(val=>{
if(val==null || val==''){
  const SecretKey = process.env.Access_Token;
  const token = jwt.sign({adminSchema},SecretKey);
  res.json({Token:token})
  const newAdmin = {
    Token : token
  }
  admin.create(newAdmin)
}
else{
    admin.findOne({Token: req.body.Token})
    .then((data)=>{
      if(data==null || data==''){
       
          res.status(404).json({
              
              success:"false",
              
            })    
      }
      else{
        const adminData = jwt.verify(req.body.Token,process.env.Access_Token)
        res.status(201).json({
            success:"true",
            body:adminData
          })
      }
    })
  }
}
)
}

