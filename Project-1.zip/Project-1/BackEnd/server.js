const app = require('./app');
const env= require('dotenv');
const AdminRoute = require('./AdminRoute');
env.config();
const UserRoute = require('./UserRoute')
const body =require('body-parser')
app.use(body.json())
app.use(body.urlencoded({extended:true}))
const port = process.env.PORT;
app.use('/Admin',AdminRoute);
app.use('/user',UserRoute);
app.listen(port,()=>{
    console.log('connected to port',port);
})
