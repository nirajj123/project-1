const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/Cart',()=>{
    console.log('connected to mongoose')
})
module.exports=mongoose;