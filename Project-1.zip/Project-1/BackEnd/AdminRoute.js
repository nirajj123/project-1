const express = require('express');
const router = express();
const MiddleWare = require('./Admin/MiddleWare')
const CreateProduct = require('./Product/CreateProduct')
const LoginAdmin = require('./Admin/LoginAdmin');
const GetAllProduct = require('./Product/GetAllProduct')
const EditProduct = require('./Product/EditProduct')
const GetAllProductByCatagory = require('./Product/GetProductByCatagory')
const DeleteProduct  = require('./Product/DeleteProduct');
const SignInAdmin = require('./Admin/SignInAdmin');
const DeleteProductByCatagory = require('./Product/DeleteProductByCatagory')
router.route('/Login').post(LoginAdmin).get(SignInAdmin)
router.route('/Product/new').post(CreateProduct)
router.route('/Product/Del/:id').delete(DeleteProduct)
router.route('/Product/All').get(GetAllProduct)
router.route('/Product/Edit/:id').put(EditProduct)
router.route('/Category/delete').get(DeleteProductByCatagory)
router.route('/Category/Read').get(GetAllProductByCatagory)
module.exports = router;